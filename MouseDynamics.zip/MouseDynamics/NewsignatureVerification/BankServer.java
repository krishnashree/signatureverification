import java.util.*;
import java.net.*;
import java.io.*;
import java.sql.*;

public class BankServer implements Runnable,serverConfig
{
	Connection con;
	Statement smt;
	StringTokenizer st;
	ResultSet rs,rs1;
	static ServerSocket serverSocket = null;
	static Socket socket = null;
	DataInputStream din;
	DataOutputStream dout;
	String msg = null,action=null,accNo,mobileNo = null;

	public BankServer(){

		try{
			   System.out.println("Server started");
			   serverSocket = new ServerSocket(7000);
			}catch(Exception df){
			  df.printStackTrace();
			  System.out.println(df);
			}
	}
	
 	public void run(){
		try{
	  			  din=new DataInputStream(socket.getInputStream());
				  dout=new DataOutputStream(socket.getOutputStream());
				  msg =din.readUTF();
				  st = new StringTokenizer(msg,"$");
				  action = st.nextToken();
				  accNo = st.nextToken();

				  Connection con = getConnection();
				  Statement stmt = con.createStatement();
				  
				  if(action.intern() == "GENERATE"){
					String sessionKey = GenerateOTP();
					rs = stmt.executeQuery("select mobilNo from userdetails where accNo='"+accNo+"'");
					if(rs.next())
						mobileNo = rs.getString(1);
					int i = stmt.executeUpdate("update userdetails set OTP='"+sessionKey+"' where accNo='"+accNo+"'");
					if(mobileNo!=null && !mobileNo.equals("")){
					SendSMS.sendMessageToMobile(sessionKey,mobileNo);
					System.out.println("Session key...."+sessionKey);
					}else{
						dout.writeUTF("NO MOBILE NO$");
					}
					if(i>0){
						
						dout.writeUTF("OK$"+sessionKey);
					}else{
						dout.writeUTF("SORRY$");
					}
				  }/*else if(action.intern() == "VALIDATION"){
					  String OTP = st.nextToken();
					rs = stmt.executeQuery("select 1 from userdetails where accNo='"+accNo+"' and OTP='"+OTP+"'");
					if(rs.next())
						dout.writeUTF("OK");
					else
						dout.writeUTF("NOTOK");
				}*/
		}catch(Exception ex){
			ex.printStackTrace();
			System.out.println(ex);
		}
	
	 }


	public static void main(String we[]){
		try{
		  BankServer bs = new BankServer();
			while(true){
				socket = serverSocket.accept();
				Thread thread = new Thread(bs);
				thread.start();
		}
		
		}catch(Exception ex){
		 ex.printStackTrace();
		 System.out.println(ex);
	 }
  }

  private Connection getConnection(){
	  try{
		  Class.forName("com.mysql.jdbc.Driver").newInstance();
		  con=DriverManager.getConnection("jdbc:mysql://"+DBIP+":3306/signatureverification","root","admin");
		  return con;
	  }catch(Exception ex){
		  ex.printStackTrace();
		  System.out.println(ex);
	  }
	  return null;
  }

  private String GenerateOTP(){
	  try{
		 String sessionkey = "";
		 int NUM_CHARS = 4;
		 String chars="ABCDEFGHIJKLMNOQRSTUVWXYZ1234567890";
		 Random r = new Random();
		 char[] buf = new char[NUM_CHARS];
         for (int i = 0; i < buf.length; i++){
               buf[i] = chars.charAt(r.nextInt(chars.length()));
           }
         sessionkey = new String(buf);
		return sessionkey;
	  }catch(Exception ex){
		  ex.printStackTrace();
		  System.out.println(ex);
	  }
	  return null;
  }
}
