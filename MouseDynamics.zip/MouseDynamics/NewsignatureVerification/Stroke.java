//Stroke.java

import java.lang.*;
import java.io.*;
import java.util.*;

public class Stroke
{
	private ArrayList Points;
	
	//constructor
	public Stroke()
	{
		Points=new ArrayList();
	}
	
	//get functions
	public int get_nPoints()
	{
		return(Points.size());
	}
	
	public Point1 getPoint(int tIndex)
	{
		Point1 tPoint=new Point1();
		
		if(tIndex>=0&&tIndex<=Points.size()-1)
		{
			tPoint=(Point1)Points.get(tIndex);
		}
		
		return(tPoint);
	}
	
	//set functions
	public void setPoint(int tIndex,Point1 tPoint)
	{
		if(tIndex>=0&&tIndex<=Points.size()-1)
		{
			Points.set(tIndex,tPoint);
		}
	}
	
	//methods
	public void addPoint(Point1 tPoint)
	{
		Point1 pt1=new Point1(tPoint.getX(),tPoint.getY(),tPoint.getDirection());
		Points.add(pt1);
	}
	//remove points
	public Point1 removePoint(int tIndex)
	{
		Point1 pt1=(Point1)Points.get(tIndex);
		Point1 tPoint=new Point1(pt1.getX(),pt1.getY());
		Points.remove(tIndex);
		return(tPoint);
	}
	
	public Point1 removePoint(Point1 tPoint)
	{
		Point1 pt2=new Point1();
		
		for(int t=0;t<=Points.size()-1;t++)
		{
			if(tPoint.isEquals(getPoint(t))==true)
			{
				Point1 pt1=(Point1)Points.get(t);
				pt2=new Point1(pt1.getX(),pt1.getY());
				removePoint(t);
				break;
			}
		}
		
		return(pt2);
	}
	
	public void removeAllPoints()
	{
		while(Points.size()!=0)
		{
			for(int t=0;t<=Points.size()-1;t++)
			{
				removePoint(t);
			}
		}
	}
	
	public String toString()
	{
		String tStr="";
		
		for(int t=0;t<=Points.size()-1;t++)
		{
			tStr+=((Point1)Points.get(t)).toString()+"\n";
		}
		
		return(tStr);
	}
}
