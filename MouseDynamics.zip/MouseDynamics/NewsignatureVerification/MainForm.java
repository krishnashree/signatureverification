import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MainForm extends JFrame {
    private Container contentPane = null;
    private JButton accountInformation,balance,fundtransfer,miniStatement,logOut;
    private String accNo = null;
    
	public MainForm(String accNo) {
		setTitle("ONLINE BANK");
		this.accNo = accNo;
		init();

	}
	
	public void init(){
		contentPane = getContentPane();
		accountInformation= new JButton();
		balance = new JButton();
		fundtransfer = new JButton();
		miniStatement = new JButton();
		logOut = new JButton();
		contentPane.setLayout(null);
		
		
		accountInformation.setText("Account Information");
		balance.setText("Balance");
		fundtransfer.setText("Fund Transfer");
		miniStatement.setText("MiniStatement");
		logOut.setText("Logout");
		
		accountInformation.setBounds(100,100,150,30);
		balance.setBounds(100,140,150,30);
		fundtransfer.setBounds(100,180,150,30);
		logOut.setBounds(100,220,150,30);
		//logOut.setBounds(100,260,150,30);
		
		addComponent(contentPane,accountInformation);
		addComponent(contentPane,balance);
		addComponent(contentPane,fundtransfer);
		//addComponent(contentPane,miniStatement);
		addComponent(contentPane,logOut);
		
		
		accountInformation.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
			  new AccountInformation(accNo);
			}
		});
		
		balance.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				new Balance(accNo);
			}
		});
		
		
		fundtransfer.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				new FundTransfer(accNo);
			}
		});
		
		/*miniStatement.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				//new MiniStatement(accNo);
			}
		});*/
		
		logOut.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				System.exit(0);
			}
		});
		
		
		setSize(300, 450);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
	
    private void addComponent(Container con,Component comp){
    	con.add(comp);
    }
	
	public static void main(String a[]){
		new MainForm("1000");
	}
	

}
