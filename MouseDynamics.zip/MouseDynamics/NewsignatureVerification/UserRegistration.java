
import javax.swing.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;

public class  UserRegistration extends JFrame implements ActionListener,serverConfig{

	private JTextField JTFName=null,JTFdob, JTFSex,JTFAddr,JTFCity,JTFMobile,JTFTown,JTFEmail,JTFANo,JTFAge,txt_image;
	private Statement stmt=null;       
	private ResultSet rs=null;
    private Socket s=null;
    DataOutputStream dout=null;
    DataInputStream din=null;
	Connection con;
	Statement smt;
	public String name,secret,ano,sex,addr,city,town,email,mob,dob,fileName,pin,age,key,path;
	File fname = null;
	JButton JBAdd;
	JButton JBbrowse;
	JButton JBCancel;

	public UserRegistration(){

	    JBAdd= new JButton("Register");
		JBbrowse = new JButton("Browse");
		JBCancel = new JButton("Cancel");
		JLabel title = new JLabel("User Registration");
		JLabel JLBanner = new JLabel("User Registration");
		JLabel JLName = new JLabel("User Name:");
		JLabel JLdob = new JLabel("DOB:");                 
		JLabel JLAge = new JLabel("Age:");
	    JLabel JLSex = new JLabel("Sex:");
	    JLabel JLAddr = new JLabel("Address:");
		JLabel JLMobile = new JLabel("Mobile:");
	    JLabel JLEmail = new JLabel("E-Mail ID:");
				
		JTFName = new JTextField();
		JTFdob = new JTextField();
		JTFANo = new JTextField();
		JTFAge = new JTextField();
		JTFSex = new JTextField();
		JTFAddr = new JTextField();
		JTFMobile = new JTextField();
	    JTFEmail = new JTextField();
					
		Dimension screen = 	Toolkit.getDefaultToolkit().getScreenSize();
		JPanel JPContainer = new JPanel();
		JPContainer.setLayout(null);
	
		JLBanner.setFont(new Font("monotype corsiva",2,20));	
		JLBanner.setBounds(85,5,150,50);
		JPContainer.add(JLBanner);
	
		JLName.setBounds(5,60,105,20);
		JTFName.setBounds(110,60,200,20);

		JLdob.setBounds(5,82,105,20);
		JTFdob.setBounds(110,82,200,20);
	
		JLSex.setBounds(5,104,105,20);
		JTFSex.setBounds(110,104,200,20);

		JLAddr.setBounds(5,126,105,20);
		JTFAddr.setBounds(110,126,200,20);

		JLAge.setBounds(5,148,105,20);
		JTFAge.setBounds(110,148,200,20);
	
		JLMobile.setBounds(5,170,105,20);
		JTFMobile.setBounds(110,170,200,20);

	   	JLEmail.setBounds(5,192,105,20);
		JTFEmail.setBounds(110,192,200,20);
		
		JBAdd.setBounds(5,310,99,25);
		JBbrowse.setBounds(112,310,99,25);
		JBCancel.setBounds(212,310,99,25);
		
		JLName.setFont(new Font("Dialog",Font.PLAIN,12));
		JTFName.setFont(new Font("Dialog",Font.PLAIN,12));
		JPContainer.add(JLName);
		JPContainer.add(JTFName);
		
		JLdob.setFont(new Font("Dialog",Font.PLAIN,12));
		JTFdob.setFont(new Font("Dialog",Font.PLAIN,12));
		JPContainer.add(JLdob);
		JPContainer.add(JTFdob);
	
		JLAge.setFont(new Font("Dialog",Font.PLAIN,12));
		JTFAge.setFont(new Font("Dialog",Font.PLAIN,12));
		JPContainer.add(JLAge);
		JPContainer.add(JTFAge);
			
		JLSex.setFont(new Font("Dialog",Font.PLAIN,12));
		JTFSex.setFont(new Font("Dialog",Font.PLAIN,12));
		JPContainer.add(JLSex);
		JPContainer.add(JTFSex);
		
		JLAddr.setFont(new Font("Dialog",Font.PLAIN,12));
		JTFAddr.setFont(new Font("Dialog",Font.PLAIN,12));
		JPContainer.add(JLAddr);
		JPContainer.add(JTFAddr);
				
		JLMobile.setFont(new Font("Dialog",Font.PLAIN,12));
		JTFMobile.setFont(new Font("Dialog",Font.PLAIN,12));
		JPContainer.add(JLMobile);
		JPContainer.add(JTFMobile);
                
		JLEmail.setFont(new Font("Dialog",Font.PLAIN,12));
		JTFEmail.setFont(new Font("Dialog",Font.PLAIN,12));
		JPContainer.add(JLEmail);
		JPContainer.add(JTFEmail);

		
		this.setTitle("UserRegistration ..."); 								
		JBAdd.setFont(new Font("Dialog", Font.PLAIN, 12));
		JBAdd.setMnemonic(KeyEvent.VK_R);
		JBAdd.setActionCommand("add");
		JBAdd.addActionListener(this);
		JPContainer.add(JBAdd);
	
		JBbrowse.setFont(new Font("Dialog", Font.PLAIN, 12));
		JBbrowse.setMnemonic(KeyEvent.VK_C);
		
			
		JBCancel.setFont(new Font("Dialog", Font.PLAIN, 12));
		JBCancel.setMnemonic(KeyEvent.VK_P);
		JBCancel.setActionCommand("cancel");
		JBCancel.addActionListener(this);
		JPContainer.add(JBCancel);
		getContentPane().add(JPContainer);
		setSize(325,400);
		setResizable(false);
		setLocation((screen.width - 325)/2,((screen.height-400)/2));
		setDefaultCloseOperation(EXIT_ON_CLOSE);
    	
	}
	
		public void actionPerformed(ActionEvent e){
				try{
					 if(e.getActionCommand().equals("add")){
					    name = JTFName.getText();
						dob = JTFdob.getText();
						sex = JTFSex.getText();
						addr = JTFAddr.getText();
						mob = JTFMobile.getText();
						email = JTFEmail.getText();
						age = JTFAge.getText();
						int aggno = 0;
						key=new newPin().getKey();
						System.out.println("PIN No.  : "+key);
						Connection con = getConnection();
						Statement stmt = con.createStatement();

					    ResultSet rs = stmt.executeQuery("select accNo from userdetails");
						while(rs.next()){
								aggno = rs.getInt(1)+1;
						}if(aggno == 0){
							aggno = 1000;
						}
											
						String ccd = " Values Added Successfully.. UR Pin No is ."+key +".. And Ur Accno"+aggno;
						int i = stmt.executeUpdate("insert into userdetails(accNo,userName,pin,dob,sex,address,email,mobilNo,balance) values('"+aggno+"','"+name+"','"+key+"','"+dob+"','"+sex+"','"+addr+"','"+email+"','"+mob+"','50000')");				
						long mob1 = Long.parseLong(mob);
						if(i>0){
							//JOptionPane.showMessageDialog(UserRegistration.this,ccd , "Mouse Dynamics...",JOptionPane.INFORMATION_MESSAGE);
							dispose();
							String accNo = ""+aggno;
							File file = new File("scripts\\English\\"+accNo);
							file.mkdirs();
							//file.close();
							//new ScriptRecognition(accNo);
							dispose();
							new TrainingWindow(accNo,name,ccd).setVisible(true);
						}else{
							JOptionPane.showMessageDialog(UserRegistration.this,"Values are not inserted into the database", "Mouse Dynamics...",JOptionPane.INFORMATION_MESSAGE);
						}
									          
			            
								
						
					}else if(e.getActionCommand().equals("cancel")){
						  dispose();	
					}
			  }catch(Exception ee) {System.out.println(ee);
					ee.printStackTrace();
					System.out.println(ee);
		     }
   }
 

  public static void main(String ar[]){
		UserRegistration fc = new UserRegistration();
		fc.setVisible(true);
   }

  private Connection getConnection(){
	 try{
		  Class.forName("com.mysql.jdbc.Driver").newInstance();
		  con=DriverManager.getConnection("jdbc:mysql://"+DBIP+":3306/signatureverification","root","admin");
		  return con;
		}catch(Exception e){e.printStackTrace();System.out.println(e);}

		return null;
	 }


 }