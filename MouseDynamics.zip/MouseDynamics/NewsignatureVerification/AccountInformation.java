
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.*;

public class AccountInformation extends JFrame implements serverConfig{
	
	private JLabel lbl_accNo,lbl_userName,lbl_address,lbl_mobileNo,lbl_email;
	private JButton submit;
	private JLabel txt_accNo,txt_userName,txt_address,txt_mobileNo,txt_email;
	private Container contentPane;
	private String accNo = null;
	String uname,address,email,mobileNo;
	public AccountInformation(String accNo) {
		this.accNo = accNo;
		init();
		setValue(accNo);
	}
	
	public void init() {
		
		contentPane = getContentPane();
		contentPane.setLayout(null);
		
		lbl_accNo = new JLabel();
		lbl_userName = new JLabel();
		lbl_address = new JLabel();
		lbl_email = new JLabel();
		lbl_mobileNo = new JLabel();
		
		
		txt_accNo = new JLabel();
		txt_userName = new JLabel();
		txt_address = new JLabel();
		txt_email = new JLabel();
		txt_mobileNo = new JLabel();
		submit = new JButton();
		
		lbl_accNo.setText("Account No :");
		lbl_userName.setText("Name  :");
		lbl_address.setText("Address :");
		lbl_email.setText("Email :");
		lbl_mobileNo.setText("Mobile No :");
		
		lbl_accNo.setBounds(10,50, 80, 20);
		txt_accNo.setBounds(150,50,100,20);
		lbl_userName.setBounds(10,70, 70, 20);
		txt_userName.setBounds(150,70,100,20);
		
		lbl_address.setBounds(10,90, 80, 20);
		txt_address.setBounds(150,90,100,20);
		lbl_email.setBounds(10,110, 70, 20);
		txt_email.setBounds(150,110,500,20);
		lbl_mobileNo.setBounds(10,130, 70, 20);
		txt_mobileNo.setBounds(150,130,100,20);
		
		
		submit.setBounds(75,150,85,20);
		
		contentPane.add(lbl_accNo);
		contentPane.add(txt_accNo);
		contentPane.add(lbl_userName);
		contentPane.add(txt_userName);
		contentPane.add(lbl_address);
		contentPane.add(txt_address);
		contentPane.add(lbl_email);
		contentPane.add(txt_email);
		contentPane.add(lbl_mobileNo);
		contentPane.add(txt_mobileNo);
		
		
		submit.setText("Submit");
		submit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				dispose();
			}
		});
		setTitle("Account Information");
		contentPane.add(submit);
		setSize(500, 300);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
	}
	
	private void setValue(String accNo) {
	 try{
		 Connection con = getConnection();
		 Statement stmt = con.createStatement();
		 ResultSet rs = stmt.executeQuery("select userName,address,email,mobilNo from userdetails where accNo='"+accNo+"'");
		 if(rs.next()){
			 uname = rs.getString(1);
			 address = rs.getString(2);
			 email = rs.getString(3);
			 mobileNo = rs.getString(4);
		 }else{
			JOptionPane.showMessageDialog(AccountInformation.this,"Account no is not valid"); 
		 }
		 txt_accNo.setText(accNo);
		 txt_userName.setText(uname);
		 txt_address.setText(address);
		 txt_email.setText(email);
		 txt_mobileNo.setText(mobileNo);
		 
	 }catch(Exception ex){
		 ex.printStackTrace();
		 System.out.println(ex);
	 }
		
	}


	private Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection(
					"jdbc:mysql://"+DBIP+":3306/signatureverification", "root", "admin");
			return connection;
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println(ex);
		}
		return null;
	}
	
	/*public static void main(String a[]){
		new Balance("1234");
	}*/
}

