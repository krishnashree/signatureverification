import com.objectxp.msg.GsmSmsService;
import com.objectxp.msg.MessageException;
import com.objectxp.msg.SmsMessage;
import com.objectxp.msg.SmsService;
import com.objectxp.msg.StatusReportMessage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;



class SendSMS
{
	static String smsMessage="",mnum;
	static long mob;

	public static void sendMessageToMobile(String smsM,String mobile)
	{
		smsMessage=smsM;
		mnum = mobile;
		//System.out.println("SMS no. : "+mnum);
		//System.out.println("SMS Message. : "+smsMessage);
		SmsService service = new GsmSmsService();

		try
		{
			service.init(new File("jsms.conf"));
			String serviceName = service.getServiceName();
			System.out.println(serviceName);
		    SmsMessage msg = new SmsMessage();
			String phno=mnum;
	        msg.setRecipient(phno);
			msg.setMessage(smsMessage);
	        service.connect();
			service.sendMessage(msg);
	        service.disconnect();
		}
		catch(IOException em)
		{
            System.out.println("IO : "+em);
            Logger.getLogger(SendSMS.class.getName()).log(Level.SEVERE, null, em);
		}
		catch (MessageException ex)
		{
			System.out.println("ME : "+ex);
		    Logger.getLogger(SendSMS.class.getName()).log(Level.SEVERE, null, ex);
		}
		finally
		{
		    service.destroy();
	    }
	}



}
