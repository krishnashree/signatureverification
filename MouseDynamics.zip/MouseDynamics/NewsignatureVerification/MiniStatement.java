import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class MiniStatement extends JFrame {

    private  Object[][] rowData = null;
    private Object[] columnNames = null;
    private Vector vector = null;

    private JTable table;
    private DefaultTableModel model;

    public MiniStatement() {
    	try{
         Container c = getContentPane();
         vector = new Vector();
         c.setLayout(new BorderLayout());
         model = new DefaultTableModel(rowData, columnNames);
         table = new JTable();
         table.setModel(model);
         Connection con = getConnection();
         Statement stmt = con.createStatement();
         ResultSet rs = stmt.executeQuery("SELECT * FROM mini_statement");
         ResultSetMetaData md = rs.getMetaData();
         int col = md.getColumnCount();
         columnNames = new Object[col];
         
         for (int i = 1; i <= col; i++){
        	   columnNames[i] = md.getColumnName(i);
         }
         rs = stmt.executeQuery("select * from mini_statement");
         if(rs.next()){
        	 vector.add(rs.getString(1));
        	 vector.add(rs.getString(2));
        	 vector.add(rs.getString(3));
        	 vector.add(rs.getString(4));
        	 vector.add(rs.getString(5));
        	 
         }
         rowData = new Object[vector.size()][vector.size()];
         vector.toArray(rowData);
         model.addRow(rowData);
         setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         pack();
    	}catch(Exception ex){
    		ex.printStackTrace();
    		System.out.println(ex);
    	}
    }
    
    

	private Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/DB", "root", "admin");
			return connection;
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println(ex);
		}
		return null;
	}
	
	/*public static void main(String a[]){
		new Balance("1234");
	}*/
}
