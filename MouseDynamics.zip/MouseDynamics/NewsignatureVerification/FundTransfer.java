import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.*;

public class FundTransfer extends JFrame implements serverConfig {
	
	private JLabel lbl_accNo,lbl_toaccNo,lbl_amount;
	private JButton submit;
	private JTextField txt_accNo,txt_toaccNo,txt_amount;
	private Container contentPane;
	private String accNo = null,toaccNo=null;
	private int balance = 0;
	private int toBalance,fromBalance,froAvailbalance,toAmount;
	

	public FundTransfer(String accNo) {
		this.accNo = accNo;
		init();
		
	}

	
	public void init() {
		
		contentPane = getContentPane();
		contentPane.setLayout(null);
		
		lbl_accNo = new JLabel();
		lbl_toaccNo = new JLabel();
		lbl_amount = new JLabel();
		txt_accNo = new JTextField();
		txt_toaccNo = new JTextField();
		txt_amount = new JTextField();
		submit = new JButton();
		
		lbl_accNo.setText("Account No :");
		lbl_toaccNo.setText("To Account No  :");
		lbl_amount.setText("Enter the Amount");
		lbl_accNo.setBounds(10,50, 100, 20);
		txt_accNo.setBounds(170,50,100,20);
		lbl_toaccNo.setBounds(10,70,150, 20);
		txt_toaccNo.setBounds(170,70,100,20);
		lbl_amount.setBounds(10,90, 100, 20);
		txt_amount.setBounds(170,90,100,20);
		
		submit.setBounds(50,120,85,20);
		
		contentPane.add(lbl_accNo);
		contentPane.add(txt_accNo);
		contentPane.add(lbl_toaccNo);
		contentPane.add(txt_toaccNo);
		contentPane.add(lbl_amount);
		contentPane.add(txt_amount);
		
		
		submit.setText("Submit");
		submit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				try{
					toaccNo = txt_toaccNo.getText();
					toAmount = Integer.parseInt(txt_amount.getText());
					if(toaccNo != null && txt_amount.getText() != null){
					
				 Connection con = getConnection();
				 Statement stmt = con.createStatement();
				 ResultSet rs = stmt.executeQuery("select balance from userdetails where accNo='"+accNo+"'");
				 if(rs.next())
					 balance = rs.getInt(1);
				 else
					 JOptionPane.showMessageDialog(FundTransfer.this, "Account no is not valid");
				 if(balance >0 && balance >=500 && toAmount< balance){
					 rs = stmt.executeQuery("select balance from userdetails where accNo='"+toaccNo+"'");
					 if(rs.next())
						 toBalance = rs.getInt(1);
					 else
						 JOptionPane.showMessageDialog(FundTransfer.this,"Invalid account");
					     fromBalance = balance - toAmount;
						 System.out.println("fromBalance..."+fromBalance);
					     toBalance = toBalance+toAmount;
						 System.out.println("Tobalance..."+toBalance);
					     int i = stmt.executeUpdate("update userdetails set balance='"+toBalance+"' where accNo='"+toaccNo+"'");
					     int j = stmt.executeUpdate("update userdetails set balance='"+fromBalance+"' where accNo='"+accNo+"'");
					     if(i>0 && j>0){
					    	 JOptionPane.showMessageDialog(FundTransfer.this,"Successfully Transfered...." );
							 dispose();
					     }else{
					    	 JOptionPane.showMessageDialog(FundTransfer.this,"Amount is not transfered..." );
					     }
					 
				 }else{
					 JOptionPane.showMessageDialog(FundTransfer.this, "Balance is insufficient to transfer");
				 }
					}else{
						JOptionPane.showMessageDialog(FundTransfer.this, "Please enter to account and amount");
					}
				 
				 
				}catch(Exception ex){
					ex.printStackTrace();
					System.out.println(ex);
				}
				
				 
			}
		});
		setTitle("Fundtransfer Form");
		contentPane.add(submit);
		setSize(300, 200);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
	}
	
	


	private Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection(
					"jdbc:mysql://"+DBIP+":3306/signatureverification", "root", "admin");
			return connection;
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println(ex);
		}
		return null;
	}
	
	/*public static void main(String a[]){
		new Balance("1234");
	}*/
}
