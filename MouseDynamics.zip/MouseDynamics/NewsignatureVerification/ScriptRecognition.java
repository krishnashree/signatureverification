//ScriptRecognition.java

import java.lang.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import java.sql.*;

public class ScriptRecognition implements ActionListener //,ListSelectionListener
{
	//ui declarations
	static String text; 
	String chkfname;
	String ftext ;
	String strTitle="Signature Verification";
	JFrame frmMain=new JFrame(strTitle);
	MyCanvas canvas1=new MyCanvas();
	JButton btNewScript=new JButton("New Script");
	JButton btEndScript=new JButton("End Script");
	JButton btSaveScript=new JButton("Save Script");
	JButton btClearScript=new JButton("Clear Script");
	private static int count = 0;
	
	JButton btDeleteAllScripts=new JButton("Delete All Scripts");
	JTextField jtf = new JTextField();
	String strScriptTypes[]={"English"};
	int CurrentScript=0;
        int strok;
	String accNo="",result="";
	//constructor
	public ScriptRecognition(String accNo,String result)
	{
		//ui definitions
		this.accNo = accNo;
		this.result = result;
		frmMain.setDefaultLookAndFeelDecorated(true);
		frmMain.setResizable(false);
		frmMain.setBounds(100,100,640,480);
		frmMain.getContentPane().setLayout(null);
		frmMain.setLocationRelativeTo(null);
		
		canvas1.setBounds(20,20,420,410);
		canvas1.setTitle("Script");
		canvas1.setDrawingInterval(20);
		frmMain.getContentPane().add(canvas1);
			
		btNewScript.setBounds(frmMain.getWidth()-180,180,160,20);
		btNewScript.addActionListener(this);
		frmMain.getContentPane().add(btNewScript);
		
		btEndScript.setBounds(frmMain.getWidth()-180,205,160,20);
		btEndScript.addActionListener(this);
		btEndScript.setEnabled(false);
		frmMain.getContentPane().add(btEndScript);
		
		btClearScript.setBounds(frmMain.getWidth()-180,230,160,20);
		btClearScript.addActionListener(this);
		btClearScript.setEnabled(false);
		frmMain.getContentPane().add(btClearScript);
		
		btSaveScript.setBounds(frmMain.getWidth()-180,270,160,20);
		btSaveScript.addActionListener(this);
		btSaveScript.setEnabled(false);
		frmMain.getContentPane().add(btSaveScript);
		
			
		btDeleteAllScripts.setBounds(frmMain.getWidth()-180,360,160,20);
		btDeleteAllScripts.addActionListener(this);
		frmMain.getContentPane().add(btDeleteAllScripts);

		

		
		frmMain.setVisible(true);
	}
	
	//events
	public void actionPerformed(ActionEvent evt)
	{
		if(evt.getSource()==btNewScript)
		{
			canvas1.Clear();
			canvas1.setEnabled(true);
			
			//lstScriptTypes.setEnabled(false);
			btNewScript.setEnabled(false);
			btEndScript.setEnabled(true);
			btClearScript.setEnabled(true);
			
			if(CurrentScript<=5)
			{
				btSaveScript.setEnabled(true);
			}
			/*else
			{
				btRecognize.setEnabled(true);
			}*/
		}
		else if(evt.getSource()==btEndScript)
		{
			canvas1.Clear();
			canvas1.setEnabled(false);

			//lstScriptTypes.setEnabled(true);
			btNewScript.setEnabled(true);
			btEndScript.setEnabled(false);
			btClearScript.setEnabled(false);
			btSaveScript.setEnabled(false);
			//btRecognize.setEnabled(false);
		}
		else if(evt.getSource()==btClearScript)
		{
			canvas1.Clear();
		}
		else if(evt.getSource()==btSaveScript)
		{
			try
			{
			if(count!=18){
			text = jtf.getText();
			//save points ,counting script counts
			int tCount=findScriptCount(CurrentScript);
			String tPath="scripts\\"+strScriptTypes[CurrentScript]+"\\"+accNo+"\\page"+tCount+".txt";
			canvas1.getCurrentPage().saveAsText(tPath);
			//setScriptList();
			
			//save image
			tPath="scripts\\"+strScriptTypes[CurrentScript]+"\\"+accNo+"\\page"+tCount+".jpg";
			canvas1.getCurrentPage().saveAsImage(tPath);
			
			//save feature
	        tPath="scripts\\"+strScriptTypes[CurrentScript]+"\\"+accNo+"\\feature"+tCount+".txt";
			canvas1.getCurrentPage().saveFeature(tPath);
			String fname = "page"+tCount+".jpg";
			/*fname.trim();
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:script");
			PreparedStatement p1=con.prepareStatement("insert into info values(?,?)");
			p1.setString(1,fname);
			p1.setString(2,text);
			p1.executeUpdate();*/
			JOptionPane.showMessageDialog(null,"New Script Saved.");
			}else if( count == 18){
				frmMain.setVisible(false);
				JOptionPane.showMessageDialog(null,"Training Phase is Completed....");
				JOptionPane.showMessageDialog(null,result);
				
				new UserLogin();
				
			}
			count ++;
			
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		/*else if(evt.getSource()==btRecognize)
		{


			int tScriptType=-1;
			int tCount=0;
			double MinDistance=0.0;
		
			for(int t=0;t<6;t++)
			{
				for(int j=0;j<Globals.MaxScripts;j++)
				{
					//delete script file, implementation of nearest neighbour algm
					String tPath="scripts\\"+strScriptTypes[t]+"\\page"+j+".txt";
					
					if(new File(tPath).exists()==true)
					{
						Page tPage=new Page();
						tPage.loadPage(tPath);
						
						if(tCount==0)
						{
							System.out.println(tCount);
							MinDistance=KNN.findDistance(tPage.getFeatureVector(),canvas1.getCurrentPage().getFeatureVector());
							tScriptType=t;
							chkfname = "page"+j+".jpg";
							System.out.println("If loop...."+chkfname);
						}
						else
						{
							double tdistance=KNN.findDistance(tPage.getFeatureVector(),canvas1.getCurrentPage().getFeatureVector());
							if(MinDistance>tdistance)
							{
								MinDistance=tdistance;
								tScriptType=t;
								chkfname = "page"+j+".jpg";
								System.out.println("else loop...."+chkfname);
							}
						}
						
						tCount+=1;
					}
				}
			}
			String ss1 = MyCanvas.ss;
			if(ss1.trim().equalsIgnoreCase("0"))
			{
			
				JOptionPane.showMessageDialog(null,"No Scripts Found.");
			
			}
			else
			{
				try
				{
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					Connection con=DriverManager.getConnection("jdbc:odbc:script");
					Statement st = con.createStatement();
					ResultSet rs = st.executeQuery("select * from info");
					while(rs.next())
					{
					String ff = rs.getString(1);
					//System.out.println("aaaaaaaaaa"+ff);
						//System.out.println("bbbbbbbbbbbbb"+chkfname.trim());
					if(ff.equalsIgnoreCase(chkfname.trim()))
						{
						ftext = rs.getString(2);
						break;
						}
					}
					String ss = strScriptTypes[tScriptType];
					JOptionPane.showMessageDialog(null,"Matched: "+ss);
					JOptionPane.showMessageDialog(null,"Word: "+ftext);
					byte data[]=ftext.getBytes();
          	    			FileOutputStream fos=new FileOutputStream("output.txt");
               				fos.write(data);
                			Runtime r = Runtime.getRuntime();
				        Process p = null;
                			p = r.exec("notepad output.txt");
				}
				catch (Exception ee)
				{
					ee.printStackTrace();
				}
			}
		}*/
		/*else if(evt.getSource()==btViewScript)//view script
		{
			if(findScriptCount(CurrentScript)==0)
			{
				JOptionPane.showMessageDialog(null,"No Saved Scripts in "+strScriptTypes[CurrentScript]+".");
				return;
			}
			
			Object tObject=JOptionPane.showInputDialog("Enter Script Number:","1");
			if(tObject instanceof String)
			{
				int tScriptNo=Integer.parseInt((String)tObject);
				String tPath="scripts\\"+strScriptTypes[CurrentScript]+"\\page"+(tScriptNo-1)+".txt";

				Page tPage=new Page();
				tPage.loadPage(tPath);
				canvas1.setCurrentPage(tPage);
			}
		}*/
		else if(evt.getSource()==btDeleteAllScripts)//deleteing allscript
		{try
		{
			int tChoice=JOptionPane.showConfirmDialog(null,"Sure to Delete ?",strTitle,JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
			if(tChoice==JOptionPane.NO_OPTION) return;
			deleteAllScripts();
			//setScriptList();
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
					Connection con=DriverManager.getConnection("jdbc:odbc:script");
					Statement st = con.createStatement();
					st.executeUpdate("delete from info");
			JOptionPane.showMessageDialog(null,"All Scripts Deleted.");
				
		}
		catch (Exception eee)
		{
			eee.printStackTrace();
		}
		}
	}
	
	/*public void valueChanged(ListSelectionEvent evt)
	{
		if(evt.getSource()==lstScriptTypes)
		{
			if(lstScriptTypes.isSelectionEmpty()==false)
			{
				CurrentScript=lstScriptTypes.getSelectedIndex();
				canvas1.setTitle(strScriptTypes[CurrentScript]);
				
				//btViewScript.setEnabled(CurrentScript!=6);
			}
		}
	}*/
	
	//internal methods vector declaration
	/*private void setScriptList()
	{
		Vector tVector=new Vector();
		for(int t=0;t<strScriptTypes.length;t++)
		{
			String tstr="";
			if(t<=5) tstr=" ("+findScriptCount(t)+")";
			tVector.add(strScriptTypes[t]+tstr);
		}
		lstScriptTypes.setListData(tVector);
	}*/
	
	private int findScriptCount(int tScriptID)
	{
		int tCount=0;
		
		for(int t=0;t<Globals.MaxScripts;t++)
		{
			String tPath="scripts\\"+strScriptTypes[tScriptID]+"\\"+accNo+"\\page"+t+".jpg";
			
			if(new File(tPath).exists()==false)
			{
				tCount=t;
				break;
			}
		}
		
		return(tCount);
	}
	
	private void deleteAllScripts()//deleting script method declaration.
	{
		for(int t=0;t<1;t++)
		{
			for(int j=0;j<Globals.MaxScripts;j++)
			{
				//delete script file
				String tPath="scripts\\"+strScriptTypes[t]+"\\"+accNo+"\\page"+j+".txt";
				if(new File(tPath).exists()==true) new File(tPath).delete();
				
				//delete script image
				tPath="scripts\\"+strScriptTypes[t]+"\\"+accNo+"\\page"+j+".jpg";
				if(new File(tPath).exists()==true) new File(tPath).delete();
				
				//delete script feature
				tPath="scripts\\"+strScriptTypes[t]+"\\"+accNo+"\\feature"+j+".txt";
				if(new File(tPath).exists()==true) new File(tPath).delete();
			}
		}
	}
	
	
	

}
