//MyCanvas.java

import java.lang.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.event.*;
import javax.swing.*;

public class MyCanvas extends JPanel implements MouseMotionListener,MouseListener
{
	//members
	private String Title;
	private Page CurrentPage;
	private int DrawingInterval;
	private boolean Enabled;
	
	//internal members
	private int TitleHeight=22;
	private long TimeStart;
	private long TimeEnd;
	
	//drawing declarations
	boolean drawing=false;
	int startx,starty;
   public static String ss;

	//constructor
	public MyCanvas()
	{
		Title="";
		CurrentPage=new Page();
		DrawingInterval=0;
		Enabled=false;
		
		this.addMouseMotionListener(this);
		this.addMouseListener(this);
	}
	
	//get functions
	public String getTitle()
	{
		return(Title);
	}
	
	public Page getCurrentPage()
	{
		return(CurrentPage);
	}
	
	public int getDrawingInterval()
	{
		return(DrawingInterval);
	}
	
	public boolean getEnabled()
	{
		return(Enabled);
	}
	
	//set functions
	public void setTitle(String tTitle)
	{
		Title=tTitle;
		repaint();
	}
	
	public void setDrawingInterval(int tDrawingInterval)
	{
		DrawingInterval=tDrawingInterval;
		repaint();
	}
	
	public void setEnabled(boolean tEnabled)
	{
		Enabled=tEnabled;
		repaint();
	}
	
	public void setCurrentPage(Page tPage)
	{
		CurrentPage=tPage;
		repaint();
	}
	
	//events
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		try
		{
			//draw title
			if(Enabled==true) g.setColor(new Color(0,0,128)); else g.setColor(new Color(128,128,128));
			g.setFont(new Font("Verdana",Font.BOLD,12));
			
			String tstr=Title;
			 tstr+=": "+CurrentPage.get_nStrokes()+" Strokes, ";
			 ss=""+CurrentPage.get_nStrokes();
			int tCount=0;
			if(CurrentPage.get_nStrokes()>0) tCount=(CurrentPage.getStroke(CurrentPage.get_nStrokes()-1)).get_nPoints();
			tstr+=tCount+" Points";
			g.drawString(tstr,4,16);
			
			//draw points
			if(Enabled==true) g.setColor(new Color(0,0,0)); else g.setColor(new Color(128,128,128));
			for(int t=0;t<CurrentPage.get_nStrokes();t++)
			{
				Stroke tStroke=CurrentPage.getStroke(t);
				
				if(tStroke.get_nPoints()==1)
				{
					Point1 p1=tStroke.getPoint(0);
					g.drawRect(p1.getX(),p1.getY(),1,1);
				}
				else if(tStroke.get_nPoints()>1)
				{
					for(int j=0;j<tStroke.get_nPoints()-1;j++)
					{
						Point1 p1=tStroke.getPoint(j);
						Point1 p2=tStroke.getPoint(j+1);
						g.drawLine(p1.getX(),p1.getY(),p2.getX(),p2.getY());
					}
				}
			}
			
			//draw border
			g.setColor(new Color(0,0,0));
			g.drawRect(0,0,getWidth()-1,getHeight()-1);
			g.drawLine(0,TitleHeight,getWidth()-1,TitleHeight);
		}
		catch(Exception err)
		{
			System.out.println("Error: "+err);
			System.exit(-1);
		}
	}

	//mousemotionlistener events
	public void mouseDragged(MouseEvent evt)
	{
		if(drawing==true)
		{
			int tx=evt.getX();
			int ty=evt.getY();

			if(ty>=TitleHeight)
			{
				TimeEnd=System.currentTimeMillis();
				long TimeTaken1=TimeEnd-TimeStart;
	
				if(TimeTaken1>=DrawingInterval)
				{
					//add point to current stroke
					int tcount=CurrentPage.getStroke(CurrentPage.get_nStrokes()-1).get_nPoints();
					int prevx=CurrentPage.getStroke(CurrentPage.get_nStrokes()-1).getPoint(tcount-1).getX();
					int tdirection=prevx<tx?Globals.LR:Globals.RL;
					CurrentPage.getStroke(CurrentPage.get_nStrokes()-1).addPoint(new Point1(tx,ty,tdirection));
					repaint();
					
					startx=tx;
					starty=ty;
					TimeStart=System.currentTimeMillis();
				}
			}
		}
	}
	
	public void mouseMoved(MouseEvent evt)
	{
		//
	}
	
	//mouselistener events
	public void mouseClicked(MouseEvent evt)
	{
		//
	}
	
	public void mouseEntered(MouseEvent evt)
	{
		//
	}
	
	public void mouseExited(MouseEvent evt)
	{
		//
	}
	
	public void mousePressed(MouseEvent evt)
	{
		if(Enabled==true)
		{
			int tx=evt.getX();
			int ty=evt.getY();
			
			if(ty>=TitleHeight)
			{
				drawing=true;
				startx=tx;
				starty=ty;
				TimeStart=System.currentTimeMillis();
				
				//add new stroke
				Stroke tStroke=new Stroke();
				tStroke.addPoint(new Point1(startx,starty,0));
				CurrentPage.addStroke(tStroke);
				repaint();
			}
		}
	}
	
	public void mouseReleased(MouseEvent evt)
	{
		drawing=false;
	}
	
	//methods
	public void Clear()
	{
		CurrentPage.removeAllStrokes();
		repaint();
	}
}
