import javax.swing.*;
import javax.swing.JOptionPane;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*; 


class OTPValidation extends JFrame implements serverConfig
 {  	
 	private JLabel jLabel1; 
 	private JLabel jLabel2;
	private JLabel jLabel3;
 
 	private JTextField jTextField1; 
 	private JPasswordField jTextField2,jTextField3; 
 	private JButton jButton1; 
 	private JButton jButton2; 
 	private JPanel contentPane;  	
	Toolkit tk;
	Dimension d;
	Connection con;
	Statement stmt;
	ResultSet rs;
	String accNo = null,sessionKey="",uname="";
 	public OTPValidation(String accNo,String sessionKey){ 
 		super(); 
		this.accNo = accNo;
		this.sessionKey = sessionKey;
 		initializeComponent();
		setResizable(false);
	    this.setVisible(true); 
	}   
 	private void initializeComponent() { 
		
		JLabel bgr; 
		bgr = new JLabel();                   
		tk = Toolkit.getDefaultToolkit();
		d = tk.getScreenSize();

 		jLabel1 = new JLabel(); 
 		jLabel2 = new JLabel(); 
		jLabel3 = new JLabel();



 		jTextField1 = new JTextField(); 
 		jTextField2 = new JPasswordField();
		jTextField3 = new JPasswordField();
 		jButton1 = new JButton(); 
 		jButton2 = new JButton(); 
		bgr.setText("OTP Validation");
		bgr.setFont(new Font("Verdana",2,12));
		contentPane = (JPanel)this.getContentPane(); 	
 		jLabel1.setText("A/c No. : ");  		
 		jLabel2.setText("  OTP.     : ");
		jLabel3.setText("  OTP.     : ");
 		jTextField1.setText(accNo);
		jTextField1.setEditable(false);
		jTextField2.setText(sessionKey);
		jTextField2.setEditable(false);
 		jTextField1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) { 
 				jTextField1_actionPerformed(e); 
 			}   
 		});  		
 		
		jTextField2.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) { 
 				jTextField2_actionPerformed(e); 
 			}   
 		});  		

		jButton1.setText("SignIn"); 
 		jButton1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) { 
				try{
					String s1=jTextField1.getText();
					String s2=jTextField3.getText();
					s2 = sessionKey+s2;
					System.out.println("sq..."+s2);
					Connection con = getConnection();
					stmt = con.createStatement();
					rs = stmt.executeQuery("select userName from userdetails where accNo='"+s1+"' and OTP='"+s2+"'");
					if(rs.next()){
						uname = rs.getString(1);
						dispose();
						new MainForm(s1);
										
					}else{
						JOptionPane.showMessageDialog(OTPValidation.this,"Invalid User " , "Mouse Dyanmics...",JOptionPane.INFORMATION_MESSAGE);
					}
				}catch (Exception ex){
					ex.printStackTrace();
					System.out.println("ERROR : "+ex);
					}
 			} 
   		});  		
 
		jButton2.setText("Reset"); 
 		jButton2.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) { 
				jTextField1.setText("");
				jTextField2.setText("");
				jTextField3.setText("");
				
			} 
   		});  	
		addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent e){
							System.exit(0);
				}
			}
		);

		contentPane.setLayout(null);
	//	contentPane.setBackground(Color.LIGHT_GRAY);           //new Color(205,125,205));

		jLabel1.setFont(new Font("Dialog",Font.PLAIN,12));
		jLabel2.setFont(new Font("Dialog",Font.PLAIN,12));
		jLabel3.setFont(new Font("Dialog",Font.PLAIN,12));
		jTextField2.setFont(new Font("Dialog",Font.PLAIN,12));
		jTextField1.setFont(new Font("Dialog",Font.PLAIN,12));
		jTextField3.setFont(new Font("Dialog",Font.PLAIN,12));
		jButton1.setFont(new Font("Dialog",Font.PLAIN,12));
		jButton2.setFont(new Font("Dialog",Font.PLAIN,12));

		addComponent(contentPane, bgr,105,0,100,50); 
 		addComponent(contentPane, jLabel1, 45,50,80,18); 
 		addComponent(contentPane, jLabel2, 42,80,80,18);
		addComponent(contentPane, jLabel3, 42,110,80,18); 
		addComponent(contentPane, jTextField1, 140,50,100,21); 
 		addComponent(contentPane, jTextField2, 140,80,100,22); 
		addComponent(contentPane, jTextField3, 140,110,100,22); 
 		addComponent(contentPane, jButton1,60,140,83,28); 
 		addComponent(contentPane, jButton2, 160,140,83,28);  		

		this.setTitle("Mouse Dyanmics  : OTPValidation ..."); 
		int x = (d.height/2) - 100;
		int y = (d.width/2) - 200;
 		this.setLocation(x,y); 
 		this.setSize(new Dimension(300,220)); 
 	}   

		
	private void addComponent(Container container,Component c,int x,int y,int width,int height) 
 	{ 
 		c.setBounds(x,y,width,height); 
 		container.add(c); 
 	}   
 	private void jTextField1_actionPerformed(ActionEvent e) 
 	{ 
 		//System.out.println("\njTextField1_actionPerformed(ActionEvent e) called.");  		 
 	} 
  
 	private void jTextField2_actionPerformed(ActionEvent e) 
 	{ 
 		//System.out.println("\njTextField2_actionPerformed(ActionEvent e) called.");  	
 	} 
  
 	private void jButton1_actionPerformed(ActionEvent e) 
 	{ 
 		//System.out.println("\njButton1_actionPerformed(ActionEvent e) called.");  		
 	} 
  
 	private void jButton2_actionPerformed(ActionEvent e) 
 	{ 
 		//System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");  	  
 	}  
	

	 private Connection getConnection(){
	 try{
		  Class.forName("com.mysql.jdbc.Driver").newInstance();
		  con=DriverManager.getConnection("jdbc:mysql://"+DBIP+":3306/signatureverification","root","admin");
		  return con;
		}catch(Exception e){e.printStackTrace();System.out.println(e);}

		return null;
	 }

	/* public static void main(String[] args) 
 	{
			new OTPValidation("5131","25");
 	} */ 
 } 
  

