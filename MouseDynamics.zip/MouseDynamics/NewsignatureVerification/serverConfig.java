import java.net.*;
interface serverConfig 
{
	public String DBIP="localhost";

	public String serverIP="localhost";
	public int serverPort=7000;
}