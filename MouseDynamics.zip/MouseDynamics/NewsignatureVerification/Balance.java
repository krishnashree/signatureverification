import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.*;

public class Balance extends JFrame implements serverConfig{
	
	private JLabel lbl_accNo,lbl_balance;
	private JButton submit;
	private JLabel txt_accNo,txt_balance;
	private Container contentPane;
	private String accNo = null;
	private double balance = 0.00;
	

	public Balance(String accNo) {
		this.accNo = accNo;
		init();
		setValue(accNo);
	}

	
	public void init() {
		
		contentPane = getContentPane();
		contentPane.setLayout(null);
		
		lbl_accNo = new JLabel();
		lbl_balance = new JLabel();
		txt_accNo = new JLabel();
		txt_balance = new JLabel();
		submit = new JButton();
		
		lbl_accNo.setText("Account No :");
		lbl_balance.setText("Balance  :");
		lbl_accNo.setBounds(10,50, 80, 20);
		txt_accNo.setBounds(100,50,30,20);
		lbl_balance.setBounds(10,70, 70, 20);
		txt_balance.setBounds(100,70,80,20);
		submit.setBounds(50,120,85,20);
		
		contentPane.add(lbl_accNo);
		contentPane.add(txt_accNo);
		contentPane.add(lbl_balance);
		contentPane.add(txt_balance);
		
		
		submit.setText("Submit");
		submit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				dispose();
			}
		});
		setTitle("Balance Form");
		contentPane.add(submit);
		setSize(190, 200);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
	}
	
	private void setValue(String accNo) {
	 try{
		 Connection con = getConnection();
		 Statement stmt = con.createStatement();
		 ResultSet rs = stmt.executeQuery("select balance from userdetails where accNo='"+accNo+"'");
		 if(rs.next()){
			 balance = rs.getDouble(1);
		 }else{
			JOptionPane.showMessageDialog(Balance.this,"Account no is not valid"); 
		 }if(balance==0){
			 txt_balance.setText("0.00");
		 }else{
			 txt_balance.setText(""+balance); 
		 }
		 //txt_balance.setText("0.00");
		 txt_accNo.setText(accNo);
		 
	 }catch(Exception ex){
		 ex.printStackTrace();
		 System.out.println(ex);
	 }
		
	}


	private Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection connection = DriverManager.getConnection(
					"jdbc:mysql://"+DBIP+":3306/signatureverification", "root", "admin");
			return connection;
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println(ex);
		}
		return null;
	}
	
	/*public static void main(String a[]){
		new Balance("1234");
	}*/
}
