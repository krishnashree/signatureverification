import javax.swing.*;
import javax.swing.JOptionPane;
import java.io.*;
import java.net.*;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*; 


class UserLogin extends JFrame implements serverConfig
 {  	
 	private JLabel jLabel1; 
 	private JLabel jLabel2; 
 
 	private JTextField jTextField1; 
 	private JPasswordField jTextField2; 
 	private JButton jButton1; 
 	private JButton jButton2; 
 	private JPanel contentPane;  	
	Toolkit tk;
	Dimension d;
	Connection con;
	Statement stmt;
	ResultSet rs;

 	public UserLogin(){ 
 		super(); 
 		initializeComponent();
		setResizable(false);
	    this.setVisible(true); 
	}   
 	private void initializeComponent() { 
		
		JLabel bgr; 
		bgr = new JLabel();                   
		tk = Toolkit.getDefaultToolkit();
		d = tk.getScreenSize();

 		jLabel1 = new JLabel(); 
 		jLabel2 = new JLabel(); 

 		jTextField1 = new JTextField(); 
 		jTextField2 = new JPasswordField(); 
 		jButton1 = new JButton(); 
 		jButton2 = new JButton(); 
		bgr.setText("User Login");
		bgr.setFont(new Font("Verdana",2,15));
		contentPane = (JPanel)this.getContentPane(); 	
 		jLabel1.setText("A/c No. : ");  		
 		jLabel2.setText("  Pin No.     : ");  		
 		
 		jTextField1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) { 
 				jTextField1_actionPerformed(e); 
 			}   
 		});  		
 		
		jTextField2.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) { 
 				jTextField2_actionPerformed(e); 
 			}   
 		});  		

		jButton1.setText("SignIn"); 
 		jButton1.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) { 
				try{
					String s1=jTextField1.getText();
					String s2=jTextField2.getText();
					Connection con = getConnection();
					stmt = con.createStatement();
					rs = stmt.executeQuery("select userName from userdetails where accNo='"+s1+"' and pin='"+s2+"'");
					if(rs.next()){
						String uname = rs.getString(1);
						dispose();
						new VerificationWindow(s1,uname).setVisible(true);	
						
					}else{
						JOptionPane.showMessageDialog(UserLogin.this,"Invalid User " , "Mouse Dyanmics...",JOptionPane.INFORMATION_MESSAGE);
					}
				}catch (Exception ex){
					ex.printStackTrace();
					System.out.println("ERROR : "+ex);
					}
 			} 
   		});  		
 
		jButton2.setText("Sign Up"); 
 		jButton2.addActionListener(new ActionListener() { 
 			public void actionPerformed(ActionEvent e) { 
				dispose();
				new UserRegistration();
			} 
   		});  	
		addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent e){
							System.exit(0);
				}
			}
		);

		contentPane.setLayout(null);
	//	contentPane.setBackground(Color.LIGHT_GRAY);           //new Color(205,125,205));

		jLabel1.setFont(new Font("Dialog",Font.PLAIN,12));
		jLabel2.setFont(new Font("Dialog",Font.PLAIN,12));
		jTextField2.setFont(new Font("Dialog",Font.PLAIN,12));
		jTextField1.setFont(new Font("Dialog",Font.PLAIN,12));
		jButton1.setFont(new Font("Dialog",Font.PLAIN,12));
		jButton2.setFont(new Font("Dialog",Font.PLAIN,12));

		addComponent(contentPane, bgr,105,0,100,50); 
 		addComponent(contentPane, jLabel1, 45,50,80,18); 
 		addComponent(contentPane, jLabel2, 42,80,80,18); 
		addComponent(contentPane, jTextField1, 140,50,100,21); 
 		addComponent(contentPane, jTextField2, 140,80,100,22); 
 		addComponent(contentPane, jButton1,60,120,83,28); 
 		addComponent(contentPane, jButton2, 160,120,83,28);  		

		this.setTitle("Mouse Dyanmics  : UserLogin ..."); 
		int x = (d.height/2) - 100;
		int y = (d.width/2) - 150;
 		this.setLocation(x,y); 
 		this.setSize(new Dimension(300,200)); 
 	}   

		
	private void addComponent(Container container,Component c,int x,int y,int width,int height) 
 	{ 
 		c.setBounds(x,y,width,height); 
 		container.add(c); 
 	}   
 	private void jTextField1_actionPerformed(ActionEvent e) 
 	{ 
 		//System.out.println("\njTextField1_actionPerformed(ActionEvent e) called.");  		 
 	} 
  
 	private void jTextField2_actionPerformed(ActionEvent e) 
 	{ 
 		//System.out.println("\njTextField2_actionPerformed(ActionEvent e) called.");  	
 	} 
  
 	private void jButton1_actionPerformed(ActionEvent e) 
 	{ 
 		//System.out.println("\njButton1_actionPerformed(ActionEvent e) called.");  		
 	} 
  
 	private void jButton2_actionPerformed(ActionEvent e) 
 	{ 
 		//System.out.println("\njButton2_actionPerformed(ActionEvent e) called.");  	  
 	}  
	public static void main(String[] args) 
 	{
			new UserLogin();
 	}  

	 private Connection getConnection(){
	 try{
		  Class.forName("com.mysql.jdbc.Driver").newInstance();
		  con=DriverManager.getConnection("jdbc:mysql://"+DBIP+":3306/signatureverification","root","admin");
		  return con;
		}catch(Exception e){e.printStackTrace();System.out.println(e);}

		return null;
	 }
 } 
  

